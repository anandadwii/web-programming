<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UsersModel;

class Orders extends BaseController
{
    public function index()
    {
        
    }

    
}
